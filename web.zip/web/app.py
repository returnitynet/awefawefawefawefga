from flask import Flask, request, jsonify, session
from flask_cors import CORS
import json
import os
import hashlib
import uuid

app = Flask(__name__)
app.secret_key = 'Geonet_90'
CORS(app, supports_credentials=True)

DB_FILE = 'cells.json'
SECRET_CODE = 'Geonet_90'

def init_db():
    if not os.path.exists(DB_FILE):
        with open(DB_FILE, 'w', encoding='utf-8') as f:
            json.dump({'items': [], 'users': [], 'sessions': {}}, f, ensure_ascii=False)

def read_db():
    with open(DB_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def write_db(data):
    with open(DB_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_next_id(key):
    data = read_db()
    items = data[key]
    return max((item['id'] for item in items), default=0) + 1

def check_session():
    data = read_db()
    session_id = request.headers.get('X-Session')
    if session_id not in data['sessions']:
        return False
    return True

@app.route('/login', methods=['POST'])
def login():
    data = read_db()
    req_data = request.get_json()
    username = req_data['username']
    password = req_data['password']
    
    user = next((u for u in data['users'] if u['username'] == username and u['password'] == password), None)
    if user:
        session_id = str(uuid.uuid4())
        data['sessions'][session_id] = username
        write_db(data)
        return jsonify({'session': session_id})
    return jsonify({'сообщение': 'Неверные учетные данные'}), 401

@app.route('/items', methods=['GET', 'POST'])
def handle_items():
    if not check_session():
        return jsonify({'сообщение': 'Не авторизован'}), 401
        
    data = read_db()
    if request.method == 'GET':
        return jsonify(data['items'])
    elif request.method == 'POST':
        req_data = request.get_json()
        new_item = {
            'id': get_next_id('items'),
            'name': req_data['name'],
            'cell_id': req_data['cell_id'],
            'is_favorite': False,
            'owner': data['sessions'][request.headers.get('X-Session')]
        }
        data['items'].append(new_item)
        write_db(data)
        return jsonify(new_item), 201

@app.route('/items/<int:item_id>', methods=['PUT', 'DELETE'])
def handle_item(item_id):
    if not check_session():
        return jsonify({'сообщение': 'Не авторизован'}), 401
        
    data = read_db()
    item_index = next((i for i, item in enumerate(data['items']) if item['id'] == item_id), None)
    if item_index is None:
        return jsonify({'сообщение': 'Деталь не найдена'}), 404

    if request.method == 'PUT':
        req_data = request.get_json()
        if 'name' in req_data:
            data['items'][item_index]['name'] = req_data['name']
        if 'cell_id' in req_data:
            data['items'][item_index]['cell_id'] = req_data['cell_id']
        write_db(data)
        return jsonify(data['items'][item_index])
    elif request.method == 'DELETE':
        data['items'].pop(item_index)
        write_db(data)
        return jsonify({'сообщение': 'Деталь удалена'})

@app.route('/favorites', methods=['POST'])
def add_favorite():
    if not check_session():
        return jsonify({'сообщение': 'Не авторизован'}), 401
        
    data = read_db()
    req_data = request.get_json()
    item_id = req_data['item_id']
    item_index = next((i for i, item in enumerate(data['items']) if item['id'] == item_id), None)
    if item_index is None:
        return jsonify({'сообщение': 'Деталь не найдена'}), 404
    
    data['items'][item_index]['is_favorite'] = True
    write_db(data)
    return jsonify(data['items'][item_index]), 201

@app.route('/favorites/<int:item_id>', methods=['DELETE'])
def remove_favorite(item_id):
    if not check_session():
        return jsonify({'сообщение': 'Не авторизован'}), 401
        
    data = read_db()
    item_index = next((i for i, item in enumerate(data['items']) if item['id'] == item_id), None)
    if item_index is None:
        return jsonify({'сообщение': 'Деталь не найдена'}), 404
    
    data['items'][item_index]['is_favorite'] = False
    write_db(data)
    return jsonify({'сообщение': 'Удалено из избранного'}), 200

@app.route('/users', methods=['POST'])
def handle_users():
    data = read_db()
    req_data = request.get_json()
    
    if req_data.get('secret_code') != SECRET_CODE:
        return jsonify({'сообщение': 'Неверный секретный код'}), 403
    
    if any(user['username'] == req_data['username'] for user in data['users']):
        return jsonify({'сообщение': 'Пользователь уже существует'}), 400
    new_user = {
        'id': get_next_id('users'),
        'username': req_data['username'],
        'password': req_data['password']
    }
    data['users'].append(new_user)
    write_db(data)
    return jsonify(new_user), 201

@app.route('/change_password', methods=['PUT'])
def change_password():
    if not check_session():
        return jsonify({'сообщение': 'Не авторизован'}), 401

    data = read_db()
    req_data = request.get_json()
    session_id = request.headers.get('X-Session')
    username = data['sessions'][session_id]
    
    user_index = next((i for i, user in enumerate(data['users']) if user['username'] == username), None)
    if user_index is None:
        return jsonify({'сообщение': 'Пользователь не найден'}), 404
    
    if data['users'][user_index]['password'] != req_data['old_password']:
        return jsonify({'сообщение': 'Неверный старый пароль'}), 401
    
    data['users'][user_index]['password'] = req_data['new_password']
    write_db(data)
    return jsonify({'сообщение': 'Пароль успешно изменен'}), 200


if __name__ == '__main__':
    init_db()
    app.run(debug=True)